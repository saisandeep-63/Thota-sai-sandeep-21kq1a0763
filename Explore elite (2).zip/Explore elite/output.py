Python 3.11.8 (tags/v3.11.8:db85d51, Feb  6 2024, 22:03:32) [MSC v.1937 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
======== RESTART: C:/Users/MY PC/OneDrive/Desktop/Explore elite/code.py ========
enter number of packages:2
enter the tourid:123
enter the source:hyd
enter the destination:ongole
enter the days:3
enter the distance:687
enter the packagecost:64670
enter the tourid:234
enter the source:goa
enter the destination:hyd
enter the days:4
enter the distance:500
enter the packagecost:43565
Tourid	source	destination	Days	Distance	Packagecost
{'tourid': 123, 'source': 'hyd', 'destination': 'ongole', 'days': 3, 'distance': 687, 'packagecost': 64670}
{'tourid': 234, 'source': 'goa', 'destination': 'hyd', 'days': 4, 'distance': 500, 'packagecost': 43565}
enter tour id:123
hyd ongole 3 687 64670
enter starting point:hyd
1
no.of days:5
2
enter the distance you require above :600
1
30000 50000
range: 1
lowest cost: 234
