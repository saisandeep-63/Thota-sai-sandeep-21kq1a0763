s=[]
def add_details(tourid,source,destination,days,distance,packagecost):
    details={
        'tourid':tourid,
        'source':source,
        'destination':destination,
        'days':days,
        'distance':distance,
        'packagecost':packagecost,
    }
    s.append(details)
n=int(input('enter number of packages:'))
for i in range(n):
    tourid=int(input('enter the tourid:'))
    source=input('enter the source:')
    destination=input('enter the destination:')
    days=int(input('enter the days:'))
    distance=int(input('enter the distance:'))
    packagecost=int(input('enter the packagecost:'))
    add_details(tourid,source,destination,days,distance,packagecost)
print('Tourid\tsource\tdestination\tDays\tDistance\tPackagecost')
for i in range(n):
    print(s[i])
tid=int(input('enter tour id:'))
for i in range(n):
    if s[i]['tourid']==tid:
        print(s[i]['source'],s[i]['destination'],s[i]['days'],s[i]['distance'],s[i]['packagecost'])
k=input('enter starting point:')
c=0
for i in range(n):
    if s[i]['source']==k:
        c=c+1
print(c)
h=int(input('no.of days:'))
j=0
for i in range(n):
    if s[i]['days']<h:
        j=j+1
print(j)
l=int(input('enter the distance you require above :'))
a=0
for i in range(n):
    if s[i]['distance']>l:
        a=a+1
print(a)
b,e=map(int,input().split())
d=0
for i in range(n):
    if s[i]['packagecost'] in range(b,e+1):
        d=d+1
print('range:',d)
f=[]
for i in range(n):
    f.append(s[i]['packagecost'])
mn=min(f)
for i in range(n):
    if s[i]['packagecost']==mn:
        print('lowest cost:',s[i]['tourid'])
    









      
    







        
